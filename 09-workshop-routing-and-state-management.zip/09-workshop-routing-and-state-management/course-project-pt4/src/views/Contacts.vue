<script>
export default {

};
</script>

<template>
  <div>
    <h2>Contacts page</h2>
  </div>
</template>

<style lang="scss" scoped></style>
