<script>
export default {

};
</script>

<template>
  <div>
    <h1>favourites</h1>
  </div>
</template>

<style lang="scss" scoped>

</style>
