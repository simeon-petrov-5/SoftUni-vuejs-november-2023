export const categories = [
  { name: 'Women\'s Dresses', value: 'womens-dresses' },
  { name: 'Women\'s Shoes', value: 'womens-shoes' },
  { name: 'Men\'s Shirts', value: 'mens-shirts' },
  { name: 'Men\'s Shoes', value: 'mens-shoes' },
  { name: 'Men\'s Watches', value: 'mens-watches' },
  { name: 'Women\'s Watches', value: 'womens-watches' },
  { name: 'Sunglasses', value: 'sunglasses' },
];
